// CSE 101 Winter 2018, PA 3
//
// DO NOT MODIFY

#ifndef __ROD_CUT_HPP__
#define __ROD_CUT_HPP__

#include <map>

#define MAX(x, y) (((x) > (y)) ? (x) : (y))

int rodcut(std::map<int, int>, int);

#endif
